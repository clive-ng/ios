//
//  M1Tests.swift
//  M1Tests
//
//  Created by Clive on 05/03/2026.
//

import Testing
@testable import M1

struct M1Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
